<?php namespace Backend\Helpers\Exception;

use ApplicationException;

class DecompileException extends ApplicationException
{
}
